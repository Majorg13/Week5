//
//  ViewController.swift
//  HamburguesasWeek5
//
//  Created by FRANCISCO RAMIREZ on 8/26/19.
//  Copyright © 2019 Majo Ramírez. All rights reserved.
//

import UIKit


class ViewController: UIViewController {
    
    let Colores = colores ()
    let nombrePaises = paises ()
    let nombreHamburguesas = hamburguesas ()

    @IBOutlet weak var MensajePais: UILabel!
    
    @IBOutlet weak var MensajeHamburguesa: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func DameOtraHamburguesa() {
        MensajePais.text = nombrePaises.regresaPaisAleatorio()
        MensajeHamburguesa.text = nombreHamburguesas.regresaHamburguesaAleatorio()
        let coloresAleatorio = Colores.regresaColoresAleatorios()
        view.backgroundColor = coloresAleatorio
    }
    struct paises {
        let paises = ["México","Sudafrica","Australia","Bolivua","Perú","Argentina","Chile","Rusia","Holanda","España","Francia","Italia","China","Noruega","Grecia","Marruecos","Estados Unidos","Canada"]
        func regresaPaisAleatorio()->String{
            let pocision = Int(arc4random()) % paises.count
            return paises[pocision]
        }
    }
    struct hamburguesas {
        let hamburguesas = ["La Juana","Western","La Famosa","SuperStar","Guacamole","Jalapeño","La Cheestosita","Portobello","LowCarb","Club Pollo","Santa Fe","Arrachera Lover","PorkyBurger","El Gordo","Salsarica","DeliPollo","La Diabla"]
        func regresaHamburguesaAleatorio()->String{
            let pocision = Int(arc4random()) % hamburguesas.count
            return hamburguesas[pocision]
        }
}
}
