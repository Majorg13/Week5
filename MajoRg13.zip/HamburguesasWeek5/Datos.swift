//
//  ArreglosHWeek5.swift
//  HamburguesasWeek5
//
//  Created by FRANCISCO RAMIREZ on 8/27/19.
//  Copyright © 2019 Majo Ramírez. All rights reserved.
//

import Foundation
import UIKit

struct colores {
    let colores = [ UIColor(red:210/255.0, green: 90/255.0, blue: 45/255.0, alpha: 1),
                    
                    UIColor(red:40/255.0, green: 170/255.0, blue: 45/255.0, alpha: 1),
                    
                    UIColor(red:3/255.0, green: 180/255.0, blue: 90/255.0, alpha: 1),
                    
                    UIColor(red:210/255.0, green: 190/255.0, blue: 5/255.0, alpha: 1),
                    
                    UIColor(red:120/255.0, green: 120/255.0, blue: 50/255.0, alpha: 1),
                    
                    UIColor(red:130/255.0, green: 80/255.0, blue: 90/255.0, alpha: 1),
                    
                    UIColor(red:130/255.0, green: 130/255.0, blue: 130/255.0, alpha: 1),
                    
                    UIColor(red:3/255.0, green: 50/255.0, blue: 90/255.0, alpha: 1)]
    
    func regresaColoresAleatorios()->UIColor {
    let posicion = Int (arc4random()) % colores.count
    return colores[posicion]
    }
        struct paises {
            let paises = ["México","Sudafrica","Australia","Bolivua","Perú","Argentina","Chile","Rusia","Holanda","España","Francia","Italia","China","Noruega","Grecia","Marruecos","Estados Unidos","Canada"]
            func regresaPaisAleatorio()->String{
                let pocision = Int(arc4random()) % paises.count
                return paises[pocision]
            }
        }
        struct hamburguesas {
            let hamburguesas = ["La Juana","Western","La Famosa","SuperStar","Guacamole","Jalapeño","La Cheestosita","Portobello","LowCarb","Club Pollo","Santa Fe","Arrachera Lover","","PorkyBurger","El Gordo","Salsarica","DeliPollo","La Diabla"]
            func regresaHamburguesaAleatorio()->String{
                let pocision = Int(arc4random()) % hamburguesas.count
                return hamburguesas[pocision]
            }
    }
}
